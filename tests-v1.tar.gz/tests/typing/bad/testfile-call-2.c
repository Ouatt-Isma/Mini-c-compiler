
int f(int x) {}
int main() { f(1, 2); }

