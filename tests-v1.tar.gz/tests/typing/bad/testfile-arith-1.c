struct S { int a; };
int main() { struct S *s; s+s; }
