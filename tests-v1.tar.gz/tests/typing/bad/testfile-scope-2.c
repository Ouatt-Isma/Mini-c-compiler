
int main() { int x; if(x) { int y; } else y; }

