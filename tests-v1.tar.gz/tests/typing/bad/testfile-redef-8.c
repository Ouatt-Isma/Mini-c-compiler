
struct S {
  int a;
};

int main() {
  int x;
  struct S* x;
}
