
int main() { int x; }
int n() { x; }
