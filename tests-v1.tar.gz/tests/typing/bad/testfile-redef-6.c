
struct S { int a; };
int f() {}
struct S* f() {}
int main() {}
