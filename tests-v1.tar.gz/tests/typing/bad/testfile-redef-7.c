
int f(int x, int y, int x) {
  return 0;
}
int main() {
  f(1, 2, 3);
}
