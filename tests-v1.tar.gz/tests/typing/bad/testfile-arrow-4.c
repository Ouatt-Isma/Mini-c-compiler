
struct S { int a; };
int foo() {}
int main() { (foo())->a; }

