int main() { 1->a; }
