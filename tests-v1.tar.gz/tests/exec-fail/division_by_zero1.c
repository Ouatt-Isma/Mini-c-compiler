int main() {
  putchar(1 / 0);
  return 0;
}
