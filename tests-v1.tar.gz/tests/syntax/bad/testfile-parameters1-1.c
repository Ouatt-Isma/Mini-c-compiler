void m(int) {}
