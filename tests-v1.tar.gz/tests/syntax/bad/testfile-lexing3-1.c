void m() { int i = 1/**/0; }
