struct S x;
int main() {}
