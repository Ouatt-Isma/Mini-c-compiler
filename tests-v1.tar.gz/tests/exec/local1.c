
int main() {
  int x;
  x = 65;
  putchar(x);
  x = 66;
  putchar(x);
  x = 67;
  putchar(x);
  putchar(10);
  return 0;
}
