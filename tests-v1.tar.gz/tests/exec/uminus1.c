
int main() {
  putchar(66 + -1);
  putchar(65 + -(-1));
  putchar(10);
  return 0;
}
