
int main() {
  int x;
  x = 65;
  putchar(x);
  if (1) {
    int y;
    y = 66;
    putchar(y);
  } else {
    int z;
    z = 67;
    putchar(z);
  }
  putchar(x);
  putchar(10);
  return 0;
}
