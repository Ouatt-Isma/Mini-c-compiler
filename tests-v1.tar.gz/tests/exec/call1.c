
int f(int x, int y) {
  putchar(x);
  return 0;
}

int main() {
  f('A', 'B');
  f('B', 'A');
  putchar(10);
  return 0;
}
