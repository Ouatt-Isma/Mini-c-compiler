
int main() {
  putchar(104);
  putchar(101);
  putchar(108);
  putchar(108);
  putchar(111);
  putchar(32);
  putchar(119);
  putchar(111);
  putchar(114);
  putchar(108);
  putchar(100);
  putchar(10);
  return 0;
}
