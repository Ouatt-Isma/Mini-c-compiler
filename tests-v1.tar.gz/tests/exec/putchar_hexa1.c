
int main() {
  putchar(0x41);
  putchar(10);
  return 0;
}
