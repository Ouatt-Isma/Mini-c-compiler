
int main() {
  putchar(65 + !0);
  putchar(65 + !1);
  putchar(10);
  return 0;
}
