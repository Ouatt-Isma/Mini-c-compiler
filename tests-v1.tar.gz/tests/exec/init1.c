
int main() {
  int x;
  // il est autorisé de ne pas initialiser une variable
  if (x == x)
    putchar('a');
  putchar(10);
  return 0;
}
