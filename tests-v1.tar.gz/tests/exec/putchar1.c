int main() {
  putchar(65);
  putchar(10);
  return 0;
}
