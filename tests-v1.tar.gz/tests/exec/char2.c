
int main() {
  int c;
  c = 'A';
  putchar(c);
  putchar(10);
  return 0;
}
